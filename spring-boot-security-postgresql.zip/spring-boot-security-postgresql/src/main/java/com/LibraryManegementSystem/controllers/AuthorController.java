package com.LibraryManegementSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LibraryManegementSystem.Exception.AuthorNotFoundException;
import com.LibraryManegementSystem.models.Author;
import com.LibraryManegementSystem.security.services.AuthorService;

@RestController
@CrossOrigin(origins = "*", maxAge = 9000)
@RequestMapping("/api/test")
public class AuthorController {

	@Autowired
	private AuthorService ser;
	
	@GetMapping("/getauthorlist")
	public List<Author> viewAuthorList() {
		return ser.viewAuthorList();
	}
	
	@GetMapping("/getby/{id}")
	public Author viewAuthorById(@PathVariable int id) throws AuthorNotFoundException {
		return ser.viewAuthorById(id);
	}
	
	@PostMapping("/addauthor")
	public int addAuthorDetails(@RequestBody Author author) throws AuthorNotFoundException {
		return ser.addAuthorDetails(author);
	}
	
	@PutMapping("/updateauthor")
	public int updateAuthorDetails(@RequestBody Author author) throws AuthorNotFoundException {
		return ser.updateAuthorDetails(author);
	}
	
	@DeleteMapping("/deleteauthor/{id}")
	public int deleteAuthorDetails(@PathVariable int id) throws AuthorNotFoundException {
		return ser.deleteAuthorDetails(id);
	}
	
	
}
