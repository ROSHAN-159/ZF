package com.LibraryManegementSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LibraryManegementSystem.Exception.BookNotFoundException;
import com.LibraryManegementSystem.models.BooksIssued;
import com.LibraryManegementSystem.security.services.BooksIssuedService;

@RestController
@CrossOrigin(origins = "*", maxAge = 9000)
@RequestMapping("/api/test")
public class BooksIssuedController {

	@Autowired
	BooksIssuedService b;

	@GetMapping("/getissuedbooks")
	public List<BooksIssued> viewBooksIssuedList() {
		return b.viewBooksIssuedList();
	}

	@PostMapping("/postissuedbooks/{id}")
	public int addIssuedBooks(@PathVariable int id, @RequestBody BooksIssued issued) throws BookNotFoundException {
		return b.addIssuedBooks(id,issued);
	}

	@PutMapping("/putissuedbooks")
	public int updateIssuedBookDetails(@RequestBody BooksIssued booksIssued) throws BookNotFoundException {
		return b.updateIssuedBookDetails(booksIssued);
	}

	@DeleteMapping("/deleteissuedbooks")
	public int deleteIssuedBooks(int bookid) throws BookNotFoundException {
		return b.deleteIssuedBooks(bookid);
	}
}
