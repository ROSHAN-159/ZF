package com.LibraryManegementSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LibraryManegementSystem.Exception.PublisherNotFoundException;
import com.LibraryManegementSystem.models.Publishers;
import com.LibraryManegementSystem.security.services.PublisherService;

@RestController
@CrossOrigin(origins = "*", maxAge =9000)
@RequestMapping("/api/test")
public class PublishersController {

	@Autowired
	PublisherService ser;

	@GetMapping("/getpublisher")
	private List<Publishers> viewPublishersList() {
		return ser.viewPublishersList();
	}

	@GetMapping("/getpublisherbyid")
	private Publishers viewPublishersById(int publisherId) throws PublisherNotFoundException {
		return ser.viewPublishersById(publisherId);
	}

	@PostMapping("/addpublisher")
	private int addPublisher(@RequestBody Publishers publisher) {
		return ser.addPublisher(publisher);
	}

	@PutMapping("/updatepublisher")
	private int updatePublisherDetails(@RequestBody Publishers publisher) {
		return ser.updatePublisherDetails(publisher);
	}

	@DeleteMapping("/deletepublisher/{publisherId}")
	public int removePublisher(@PathVariable int publisherId) throws PublisherNotFoundException {
		return ser.removePublisher(publisherId);
	}

}
