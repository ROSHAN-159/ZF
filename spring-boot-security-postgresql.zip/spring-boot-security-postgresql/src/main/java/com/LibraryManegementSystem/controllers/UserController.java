package com.LibraryManegementSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LibraryManegementSystem.Exception.UserNotFoundException;
import com.LibraryManegementSystem.models.User;
import com.LibraryManegementSystem.security.services.UserDetailsServiceImpl;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	UserDetailsServiceImpl service;

	@GetMapping("/users")
	public List<User> getAlllUsers() {
		return service.getAllUser();
	}

	@DeleteMapping("/users/{id}")
	public int deletebyid(@PathVariable Long id) throws UserNotFoundException {
		service.deleteUser(id);
		return 1;
	}

	@PutMapping("/auth/cancleSubcriptionby/{userid}")
	public int cancleSubcription(@PathVariable Long userid) throws UserNotFoundException {
		return service.cancleSubcription(userid);
	}
}
