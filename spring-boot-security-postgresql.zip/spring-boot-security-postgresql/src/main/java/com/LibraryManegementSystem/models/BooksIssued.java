package com.LibraryManegementSystem.models;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "BooksIssued")
public class BooksIssued {
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int issueId;

	@OneToMany(cascade = CascadeType.PERSIST)
	@JsonIgnore
	private List<Books> books;

	@Column
	private LocalDate issueDate;

	@Column
	private int quantity;

	@Column
	private LocalDate dueDate;

	public BooksIssued() {
		super();
	}

	public BooksIssued(int issueId, List<Books> books, LocalDate issueDate, int quantity, LocalDate dueDate) {
		super();
		this.issueId = issueId;
		this.books = books;
		this.issueDate = issueDate;
		this.quantity = quantity;
		this.dueDate = dueDate;
	}

	public int getIssueId() {
		return issueId;
	}

	public void setIssueId(int issueId) {
		this.issueId = issueId;
	}

	public List<Books> getBooks() {
		return books;
	}

	public void setBooks(List<Books> books) {
		this.books = books;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate date) {
		this.issueDate = date;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

}