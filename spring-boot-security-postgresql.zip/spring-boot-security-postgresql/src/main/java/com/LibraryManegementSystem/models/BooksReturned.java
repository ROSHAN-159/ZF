package com.LibraryManegementSystem.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Books_Returned")
public class BooksReturned {
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;

	@Column
	private Date returnedDate;
	@Column
	private int delayed_Days;
	@Column
	private double penalty;
	@Column
	private String penalty_status;

	@OneToOne
	private User user;

	public BooksReturned() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BooksReturned(int id, Date returnedDate, int delayed_Days, double penalty, String penalty_status,
			User user) {
		super();
		Id = id;
		this.returnedDate = returnedDate;
		this.delayed_Days = delayed_Days;
		this.penalty = penalty;
		this.penalty_status = penalty_status;
		this.user = user;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public Date getReturnedDate() {
		return returnedDate;
	}

	public void setReturnedDate(Date returnedDate) {
		this.returnedDate = returnedDate;
	}

	public int getDelayed_Days() {
		return delayed_Days;
	}

	public void setDelayed_Days(int delayed_Days) {
		this.delayed_Days = delayed_Days;
	}

	public double getPenalty() {
		return penalty;
	}

	public void setPenalty(double penalty) {
		this.penalty = penalty;
	}

	public String getPenalty_status() {
		return penalty_status;
	}

	public void setPenalty_status(String penalty_status) {
		this.penalty_status = penalty_status;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}