package com.LibraryManegementSystem.models;

public enum ERole {
  ROLE_MODERATOR,
  ROLE_ADMIN
}
