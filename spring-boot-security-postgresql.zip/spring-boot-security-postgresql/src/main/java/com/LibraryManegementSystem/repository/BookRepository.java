package com.LibraryManegementSystem.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.LibraryManegementSystem.models.Books;

@Repository
public interface BookRepository extends CrudRepository<Books,Integer>{

	List<Books> findByTitle(String keyword);

	List<Books> findBySubject(String keyword);


}
