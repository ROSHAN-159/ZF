package com.LibraryManegementSystem.security.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.Exception.BookNotFoundException;
import com.LibraryManegementSystem.models.SuggestedBooks;
import com.LibraryManegementSystem.repository.SuggestedBooksRepository;

@Service
public class SuggestedBooksService {
	private static final Logger log = LoggerFactory.getLogger(SuggestedBooksService.class);

	@Autowired
	private SuggestedBooksRepository repo;

	

	public int addSuggestedBooks(SuggestedBooks books) {
		SuggestedBooks sbbok = new SuggestedBooks();
		sbbok.setAuthor(books.getAuthor());
		sbbok.setDescription(books.getDescription());
		sbbok.setPublications(books.getPublications());
		sbbok.setStatus("Pending Approval ");
		sbbok.setSubject(books.getSubject());
		sbbok.setTitle(books.getTitle());
		sbbok.setSuggested_date(books.getSuggested_date());
		log.info("Adding SuggestedBook...");
		try {
			repo.save(sbbok);
			log.info("SuggestedBook Added!!");
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public int updateSuggestedBookStatus(int id, SuggestedBooks book) {
		SuggestedBooks books = repo.findById(id).get();
		books.setStatus("Accepted");
		log.info("Updating SuggestedBook Status...");
		try {
			repo.save(books);
			log.info("SuggestedBook Status Updated!!");
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public int deleteSuggestedBooks(int id) throws BookNotFoundException {
		log.info("Removing Book...");
		try {
			repo.deleteById(id);
			log.info("Book B");
			return 1;
		} catch (Exception e) {
			throw new BookNotFoundException("SuggestedBook does not exist");
		}
	}

	public SuggestedBooks viewSuggestedBookDetails(int id) throws BookNotFoundException {
		SuggestedBooks bs = null;
		try {
			bs = repo.findById(id).get();
			log.info("SuggestedBook Fetched!!");
			return bs;
		} catch (Exception e) {
			throw new BookNotFoundException("SuggestedBook does not exist");
		}
	}

	public List<SuggestedBooks> viewSuggestedBooksList1() {
		List<SuggestedBooks> lst = null;
		try {
			log.info("Fetching Book Details...");
			lst = (List<SuggestedBooks>) repo.findAll();
			log.info("SuggestedBook Details Fetched!!");
			return lst;
		} catch (Exception e) {
			return lst;
		}
	}
	public SuggestedBooksService(SuggestedBooksRepository repo2) {
		super();
	}
}
