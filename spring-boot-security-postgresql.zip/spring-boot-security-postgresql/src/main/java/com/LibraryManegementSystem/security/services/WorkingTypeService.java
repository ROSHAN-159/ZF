package com.LibraryManegementSystem.security.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.models.WorkModeType;
import com.LibraryManegementSystem.repository.UserRepository;
import com.LibraryManegementSystem.repository.WorkingModeReposistory;

@Service
public class WorkingTypeService {

	@Autowired
	WorkingModeReposistory repo;

	@Autowired
	UserRepository urepo;

	public String saveWorkingType(WorkModeType modeType) {
			LocalDate date = LocalDate.now();
			WorkModeType wmt = new WorkModeType();
			wmt.setLocalDate(date);
			wmt.setStatus("Pending");
			wmt.setUserID(2);
			wmt.setWorkmodeType(modeType.getWorkmodeType());
			repo.save(wmt);
			return "Working Mode Added";
		

	}

//	public WorkModeType getMonthlyStatus(String id) {
//		try {
//			WorkModeType workmodetype = repo.findByWorkmodeType(id);
//			System.out.println(workmodetype);
//			return workmodetype;
//		} catch (Exception e) {
//			System.out.println("not found");
//		}
//		return null;
//
//	}

	public List<WorkModeType> getallmode() {
		return (List<WorkModeType>) repo.findAll();

	}

}
